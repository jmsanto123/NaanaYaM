#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Naanayam-Qt message queue name
#define BOUNTYCOINURI_QUEUE_NAME "NaanayamURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
