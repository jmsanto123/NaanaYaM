
Naanayam [NYM]

SHA256 PoW/PoS

10 second block target, linear (per-block) difficulty readjustment

1 Coin Per Block

100,000,000,000,000 (unlimited) total coinage via Proof of Work

100 Confirms for Coin Maturity

140 Character TX Messaging

3% Annual Stake, 90 days to stake, 120 days to full weight

Default RPC Port = 14444

Default P2P Port = 14445